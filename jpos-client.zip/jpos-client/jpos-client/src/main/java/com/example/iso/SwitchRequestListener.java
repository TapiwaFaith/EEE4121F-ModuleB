package com.example.iso;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.jpos.core.Configurable;
import org.jpos.core.Configuration;
import org.jpos.core.ConfigurationException;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISORequestListener;
import org.jpos.iso.ISOSource;
import org.jpos.iso.MUX;
import org.jpos.q2.iso.QMUX;
import org.jpos.util.NameRegistrar.NotFoundException;

public class SwitchRequestListener implements ISORequestListener, Configurable {

    private Map<String, String> routeTable;
    @Override
    public void setConfiguration(Configuration configuration) throws ConfigurationException {
        // TODO Auto-generated method stub
        routeTable = new HashMap<>();  
        routeTable.put("8001", "server_1");
        routeTable.put("8002", "server_2");      
    }

    @Override
    public boolean process(ISOSource isoSource, ISOMsg isoMsg) {
        // TODO Auto-generated method stub
        try {
            if(isoMsg.getMTI().equals("0200"))
            {
                Thread t = new Thread(new Processor(isoSource, isoMsg));
                t.start();
                return true;
            }          
            
        } catch (ISOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return false;
    }

    class Processor implements Runnable
    {
        private ISOSource isoSource;
        private ISOMsg isoMsg;

        public Processor(ISOSource isoSource, ISOMsg isoMsg)
        {
            this.isoSource = isoSource;
            this.isoMsg = isoMsg;
        }

        @Override
        public void run() {
            // TODO Auto-generated method stub
            
            try {
                String fiid = isoMsg.getString( 120);
                String serverName = routeTable.get(fiid);

                MUX mux = QMUX.getMUX(serverName + "-mux");
                ISOMsg respMsg = mux.request(isoMsg, 30000);
                
                if(respMsg != null)
                {
                    isoSource.send(respMsg);
                }
            } catch (NotFoundException | ISOException | IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            
        }
        
    }
}
